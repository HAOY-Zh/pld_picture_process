"""Isolated reviewed shared-engine drivers; model/RTL bytes frozen."""
