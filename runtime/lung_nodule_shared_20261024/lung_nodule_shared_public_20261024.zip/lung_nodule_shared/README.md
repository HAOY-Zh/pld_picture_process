# Shared U-Net / nodule engine — synthetic deployment

This package contains the accepted 100 MHz bit, unchanged model weights, Python/C++ drivers and matching RTL. It has no CT files, patient-derived self-test activations or deployment credentials. Self-test inputs are analytic/seeded synthetic codes. New synthetic references passed independent FP64 and C++ integer checks; these exact synthetic fixtures have NOT yet run on the physical board. Historical real-board acceptance is recorded separately in the repository.

Copy this whole directory to /home/xilinx/ct_test/. In the board Jupyter kernel stop other FPGA owners, then run:

```python
%run /home/xilinx/ct_test/lung_nodule_shared/lung_nodule_shared_benchmark.py --cycles 2 --out /home/xilinx/ct_test/lung_nodule_shared_public_01
```

Requires an existing PYNQ-Z2 PYNQ image, NumPy and g++; no Torch, CUDA, model download or private token. The native MMIO library compiles on first start. Do not load another Overlay while this driver owns the FPGA.

A PASS verifies synthetic network execution and model switching, not nodule detection quality. U-Net inputs are 1x256x256 U8 codes; nodule inputs are lowered 45x64x64 codes derived from five 128x128 contexts. Their original quantization, sampling and geometry contracts still apply. The patch benchmark excludes CT sampling and candidate decoding. See docs/肺分割与结节共享引擎GitHub交付_20261024.md in the source repository for integration and independent return verification.
