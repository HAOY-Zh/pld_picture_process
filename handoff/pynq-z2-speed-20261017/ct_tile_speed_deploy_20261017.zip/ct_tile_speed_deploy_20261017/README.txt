PYNQ-Z2 CT denoising bundle

1. Upload the entire directory to the board, preserving subdirectories.
2. Open run_board_test.ipynb and run the cells in order.
3. First test bypass and Gaussian: --modes 0 1. Then run all modes.
4. Every output must match the CPU integer reference pixel-for-pixel.
5. board_result.json records actual PL execution and complete DMA+PL+PS time.
6. Keep board_results_001; use another output name for repeat experiments.

CPU: file I/O, tile overlap/packing, DMA control, result checking and display.
PL: Gaussian, bilateral, joint bilateral, guided filter and integer CNN.
CNN: fixed audited weights; int8 weights/int16 activations/int32 accumulator.
CPU reference timing is for correctness; not an optimized ARM baseline.
PC simulation and implementation do not establish board speed or reliability.

Speed test: open run_speed_test.ipynb, or run:
python3 pynq/benchmark_ct_tile_speed.py --outdir board_speed_001 --repeats 5
This compares legacy48, fast48, fast58, compact58 on BOTH real samples.
Every output must match the SAME old integer model; new training weights are not included.
Results include PS packing, DMA/cache, PL and reassembly.
